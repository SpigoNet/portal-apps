<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <h2 class="font-semibold text-xl text-gray-800 dark:text-gray-200 leading-tight">
            <?php echo e(__('Seleção de Configuração DSpace XML')); ?>

        </h2>
     <?php $__env->endSlot(); ?>

    <div class="py-12">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
            <div class="bg-white dark:bg-gray-800 overflow-hidden shadow-sm sm:rounded-lg">
                <div class="p-6 text-gray-900 dark:text-gray-100">

                    <div class="flex justify-between items-center mb-6">
                        <h3 class="text-xl font-semibold"><?php echo e(__('Selecione uma Configuração para Gerenciar')); ?></h3>
                        <a href="<?php echo e(route('dspace-forms.configurations.create')); ?>" class="inline-flex items-center px-4 py-2 bg-green-600 border border-transparent rounded-md font-semibold text-xs text-white uppercase tracking-widest hover:bg-green-700 focus:outline-none focus:border-green-900 focus:ring ring-green-300 disabled:opacity-25 transition ease-in-out duration-150">
                            <?php echo e(__('Criar Nova Configuração')); ?>

                        </a>
                    </div>

                    <?php if(session('success')): ?>
                        <div class="bg-green-100 border border-green-400 text-green-700 px-4 py-3 rounded relative mb-4" role="alert">
                            <?php echo e(session('success')); ?>

                        </div>
                    <?php endif; ?>
                    <?php if(session('error')): ?>
                        <div class="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded relative mb-4" role="alert">
                            <?php echo e(session('error')); ?>

                        </div>
                    <?php endif; ?>

                    <div class="mt-6">
                        <?php if($allConfigurations->isEmpty()): ?>
                            <p class="text-center text-gray-500"><?php echo e(__('Nenhuma configuração encontrada. Crie uma para começar.')); ?></p>
                        <?php else: ?>
                            <div class="space-y-4">
                                <?php $__currentLoopData = $allConfigurations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $config): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="p-4 bg-gray-50 dark:bg-gray-700 rounded-lg shadow-md flex justify-between items-center">
                                        <div>
                                            <p class="text-lg font-bold"><?php echo e($config->name); ?></p>
                                            <p class="text-sm text-gray-500 dark:text-gray-400"><?php echo e($config->description ?? 'Nenhuma descrição fornecida.'); ?></p>
                                        </div>
                                        <div class="flex space-x-3">
                                            
                                            <a href="<?php echo e(route('dspace-forms.index', ['config_id' => $config->id])); ?>" class="text-indigo-600 dark:text-indigo-400 hover:text-indigo-900 font-semibold text-sm">
                                                <?php echo e(__('Gerenciar')); ?>

                                            </a>

                                            
                                            <form action="<?php echo e(route('dspace-forms.configurations.duplicate', $config)); ?>" method="POST" class="inline" onsubmit="return confirm('Tem certeza que deseja duplicar a configuração \'<?php echo e($config->name); ?>\'?')">
                                                <?php echo csrf_field(); ?>
                                                <button type="submit" class="text-yellow-600 dark:text-yellow-400 hover:text-yellow-900 font-semibold text-sm">
                                                    <?php echo e(__('Duplicar')); ?>

                                                </button>
                                            </form>
                                        </div>
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH C:\laragon\www\portal-apps\app\Modules\DspaceForms/resources/views/selection.blade.php ENDPATH**/ ?>