<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <div class="flex justify-between items-center">
            <h2 class="font-semibold text-xl text-gray-800 dark:text-gray-200 leading-tight">
                <?php echo e(__('Editor de Configurações DSpace')); ?>

            </h2>
            <div class="flex items-center space-x-4">

                
                <form id="config-selector-form" action="<?php echo e(route('dspace-forms.index')); ?>" method="GET" class="inline-flex">
                    <select name="config_id" id="config-selector"
                            class="border-gray-300 dark:border-gray-700 dark:bg-gray-900 dark:text-gray-300 focus:border-indigo-500 dark:focus:border-indigo-600 focus:ring-indigo-500 dark:focus:ring-indigo-600 rounded-md shadow-sm text-sm">

                        <option value="" disabled><?php echo e(__('Configuração Atual:')); ?></option>

                        
                        <?php $__currentLoopData = $allConfigurations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $availableConfig): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($availableConfig->id); ?>"
                                    <?php if($availableConfig->id == $stats['config_id']): ?> selected <?php endif; ?>>
                                <?php echo e($availableConfig->name); ?>

                            </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        
                        <option value="" disabled>--- AÇÕES ---</option>

                        
                        <option value="create"><?php echo e(__('Criar Nova Configuração')); ?></option>

                        
                        <option value="duplicate-<?php echo e($stats['config_id']); ?>"><?php echo e(__('Duplicar Configuração Atual')); ?></option>
                    </select>
                </form>

                <a href="<?php echo e(route('dspace-forms.index')); ?>">
                    <?php if (isset($component)) { $__componentOriginal3b0e04e43cf890250cc4d85cff4d94af = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal3b0e04e43cf890250cc4d85cff4d94af = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.secondary-button','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('secondary-button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
                        <i class="fa-solid fa-house mr-2"></i> <?php echo e(__('Início')); ?>

                     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal3b0e04e43cf890250cc4d85cff4d94af)): ?>
<?php $attributes = $__attributesOriginal3b0e04e43cf890250cc4d85cff4d94af; ?>
<?php unset($__attributesOriginal3b0e04e43cf890250cc4d85cff4d94af); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal3b0e04e43cf890250cc4d85cff4d94af)): ?>
<?php $component = $__componentOriginal3b0e04e43cf890250cc4d85cff4d94af; ?>
<?php unset($__componentOriginal3b0e04e43cf890250cc4d85cff4d94af); ?>
<?php endif; ?>
                </a>

                
                <script>
                    document.getElementById('config-selector').addEventListener('change', function() {
                        const selectedValue = this.value;
                        const currentConfigId = '<?php echo e($stats['config_id']); ?>';

                        if (selectedValue === 'create') {
                            // Redireciona para a rota de criação
                            window.location.href = "<?php echo e(route('dspace-forms.configurations.create')); ?>";
                        } else if (selectedValue.startsWith('duplicate-')) {
                            const configId = selectedValue.split('-')[1];

                            // Cria e submete um formulário POST para a duplicação (mais seguro)
                            if (confirm("Tem certeza que deseja duplicar a configuração '<?php echo e($stats['config_name']); ?>'?")) {
                                const form = document.createElement('form');
                                form.method = 'POST';
                                form.action = "<?php echo e(route('dspace-forms.configurations.duplicate', ':id')); ?>".replace(':id', configId);

                                // Adiciona o token CSRF
                                const csrfToken = document.createElement('input');
                                csrfToken.type = 'hidden';
                                csrfToken.name = '_token';
                                csrfToken.value = '<?php echo e(csrf_token()); ?>';
                                form.appendChild(csrfToken);

                                document.body.appendChild(form);
                                form.submit();
                            } else {
                                // Se cancelar, reseta o dropdown para a opção selecionada
                                this.value = currentConfigId;
                            }
                        } else {
                            // Ação padrão (trocar configuração)
                            document.getElementById('config-selector-form').submit();
                        }
                    });
                </script>

                
                <a href="<?php echo e(route('dspace-forms.export.zip', $stats['config_id'] ?? 0)); ?>" class="inline-flex items-center px-4 py-2 bg-blue-600 border border-transparent rounded-md font-semibold text-xs text-white uppercase tracking-widest hover:bg-blue-500 active:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2 dark:focus:ring-offset-gray-800 transition ease-in-out duration-150">
                    <i class="fa-solid fa-file-zipper mr-2"></i>
                    <?php echo e(__('Exportar Configurações (.zip)')); ?>

                </a>
            </div>
        </div>
     <?php $__env->endSlot(); ?>

    

    <div class="py-12">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
            <div class="grid grid-cols-1 md:grid-cols-3 gap-6">

                <div class="bg-white dark:bg-gray-800 overflow-hidden shadow-sm sm:rounded-lg">
                    <div class="p-6 text-gray-900 dark:text-gray-100">
                        <div class="flex items-center">
                            <i class="fa-solid fa-file-alt fa-2x text-indigo-500 mr-4"></i>
                            <div>
                                <h3 class="text-lg font-semibold"><?php echo e(__('Lista de Formulários')); ?></h3>
                                <p class="text-2xl font-bold"><?php echo e($stats['forms_count']); ?></p>
                                <p class="text-sm text-gray-500 dark:text-gray-400"><?php echo e(__('formulários configurados')); ?></p>
                            </div>
                        </div>
                        <div class="mt-4 text-right">
                            <a href="<?php echo e(route('dspace-forms.forms.index', ['config_id' => $stats['config_id']])); ?>" class="text-indigo-600 hover:text-indigo-900 dark:text-indigo-400 dark:hover:text-indigo-300 font-semibold">
                                <?php echo e(__('Gerenciar Formulários')); ?> &rarr;
                            </a>
                        </div>
                    </div>
                </div>

                <div class="bg-white dark:bg-gray-800 overflow-hidden shadow-sm sm:rounded-lg">
                    <div class="p-6 text-gray-900 dark:text-gray-100">
                        <div class="flex items-center">
                            <i class="fa-solid fa-list-check fa-2x text-green-500 mr-4"></i>
                            <div>
                                <h3 class="text-lg font-semibold"><?php echo e(__('Vocabulários e Listas')); ?></h3>
                                <p class="text-2xl font-bold"><?php echo e($stats['vocabularies_count']); ?></p>
                                <p class="text-sm text-gray-500 dark:text-gray-400"><?php echo e(__('listas de valores gerenciadas')); ?></p>
                            </div>
                        </div>
                        <div class="mt-4 text-right">
                            <a href="<?php echo e(route('dspace-forms.value-pairs.index', ['config_id' => $stats['config_id']])); ?>" class="text-indigo-600 hover:text-indigo-900 dark:text-indigo-400 dark:hover:text-indigo-300 font-semibold">
                                <?php echo e(__('Gerenciar Vocabulários')); ?> &rarr;
                            </a>
                        </div>
                    </div>
                </div>


                <div class="bg-white dark:bg-gray-800 overflow-hidden shadow-sm sm:rounded-lg">
                    <div class="p-6 text-gray-900 dark:text-gray-100">
                        <div class="flex items-center">
                            <i class="fa-solid fa-link fa-2x text-orange-500 mr-4"></i>
                            <div>
                                <h3 class="text-lg font-semibold"><?php echo e(__('Vínculos Comunidade/Coleção')); ?></h3>
                                <p class="text-2xl font-bold"><?php echo e($stats['maps_count']); ?></p>
                                <p class="text-sm text-gray-500 dark:text-gray-400"><?php echo e(__('vínculos configurados')); ?></p>
                            </div>
                        </div>
                        <div class="mt-4 text-right">
                            <a href="<?php echo e(route('dspace-forms.form-maps.index', ['config_id' => $stats['config_id']])); ?>" class="text-indigo-600 hover:text-indigo-900 dark:text-indigo-400 dark:hover:text-indigo-300 font-semibold">
                                <?php echo e(__('Gerenciar Vínculos')); ?> &rarr;
                            </a>
                        </div>
                    </div>
                </div>

            </div>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH C:\laragon\www\portal-apps\app\Modules\DspaceForms/resources/views/index.blade.php ENDPATH**/ ?>