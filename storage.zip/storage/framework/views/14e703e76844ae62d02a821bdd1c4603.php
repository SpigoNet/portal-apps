<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <div class="flex flex-col md:flex-row md:justify-between md:items-center space-y-2 md:space-y-0">
            <div class="flex items-center">
                <h2 class="font-semibold text-xl text-gray-800 leading-tight mr-4">
                    <?php echo e($projeto->nome); ?>

                </h2>
                <span class="px-2 py-1 text-xs rounded bg-gray-200 text-gray-600"><?php echo e($projeto->status); ?></span>
            </div>

            <div class="flex items-center space-x-2 overflow-x-auto">
                <a href="<?php echo e(route('treetask.index')); ?>"
                   class="text-gray-600 hover:text-gray-900 bg-white border border-gray-300 px-3 py-1 rounded text-sm shadow-sm whitespace-nowrap">
                    📂 Projetos
                </a>

                <?php if(Route::currentRouteName() == 'treetask.show'): ?>
                    <a href="<?php echo e(route('treetask.tree.view', $projeto->id_projeto)); ?>"
                       class="text-purple-700 hover:text-purple-900 bg-purple-50 border border-purple-200 px-3 py-1 rounded text-sm font-bold shadow-sm whitespace-nowrap">
                        Ver Árvore 🌳
                    </a>
                <?php else: ?>
                    <a href="<?php echo e(route('treetask.show', $projeto->id_projeto)); ?>"
                       class="text-blue-700 hover:text-blue-900 bg-blue-50 border border-blue-200 px-3 py-1 rounded text-sm font-bold shadow-sm whitespace-nowrap">
                        Ver Kanban 📋
                    </a>
                <?php endif; ?>

                <span class="text-gray-300">|</span>

                <a href="<?php echo e(route('treetask.focus.index')); ?>"
                   class="text-white bg-indigo-600 hover:bg-indigo-700 px-3 py-1 rounded text-sm font-bold shadow-sm whitespace-nowrap">
                    Modo Zen 🧘
                </a>
            </div>
        </div>
     <?php $__env->endSlot(); ?>

    <div class="py-6 h-screen overflow-x-auto">
        <div class="max-w-full mx-auto sm:px-6 lg:px-8 h-full">

            <?php if(session('success')): ?>
                <div class="mb-4 bg-green-100 border-l-4 border-green-500 text-green-700 p-4">
                    <?php echo e(session('success')); ?>

                </div>
            <?php endif; ?>

            <div id="kanban-container" class="flex space-x-4 h-full items-start pb-4">
                <?php $__currentLoopData = $projeto->fases; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $fase): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div data-fase-id="<?php echo e($fase->id_fase); ?>"
                         class="min-w-[300px] bg-gray-100 rounded-lg shadow-md max-h-full flex flex-col">
                        <div
                            class="fase-handle cursor-move p-4 border-b border-gray-200 bg-gray-200 rounded-t-lg flex justify-between items-center">
                            <h3 class="font-bold text-gray-700"><?php echo e($fase->nome); ?></h3>
                            <span class="text-xs text-gray-500 font-mono"><?php echo e($fase->tarefas->count()); ?></span>
                        </div>

                        <div class="tarefas-container p-2 overflow-y-auto flex-1 space-y-2 custom-scrollbar"
                             id="fase-<?php echo e($fase->id_fase); ?>">
                            <?php $__currentLoopData = $fase->tarefas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tarefa): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php
                                    $isConcluido = ($tarefa->status == 'Concluído');
                                    $priorityClass = '';
                                    if (!$isConcluido) {
                                        $priorityClass = match ($tarefa->prioridade) {
                                            'Urgente' => 'border-red-500',
                                            'Alta' => 'border-orange-400',
                                            default => 'border-blue-400',
                                        };
                                    }
                                ?>

                                <div data-tarefa-id="<?php echo e($tarefa->id_tarefa); ?>" class="bg-white p-3 rounded border shadow-sm transition cursor-grab
        <?php echo e($isConcluido ? 'opacity-70 bg-green-50 border-green-400' : 'hover:shadow-md'); ?> border-l-4
        <?php echo e($isConcluido ? 'border-green-400' : $priorityClass); ?>">

                                    <div class="flex justify-between items-start">

                                        <a href="<?php echo e(route('treetask.tarefas.show', $tarefa->id_tarefa)); ?>" class="block flex-1">
                                            <h4 class="font-semibold text-sm mb-1
                    <?php echo e($isConcluido ? 'line-through text-gray-500' : 'text-gray-800 hover:text-blue-600'); ?>">
                                                <?php echo e($tarefa->titulo); ?>

                                            </h4>
                                        </a>

                                        <a href="<?php echo e(route('treetask.tarefas.edit', $tarefa->id_tarefa)); ?>" class="text-gray-400 hover:text-blue-500 ml-2 flex-shrink-0" title="Editar / Mover">
                                            <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" class="w-4 h-4">
                                                <path stroke-linecap="round" stroke-linejoin="round" d="m16.862 4.487 1.687-1.688a1.875 1.875 0 1 1 2.652 2.652L10.582 16.07a4.5 4.5 0 0 1-1.897 1.13L6 18l.8-2.685a4.5 4.5 0 0 1 1.13-1.897l8.932-8.931Zm0 0L19.5 7.125M18 14v4.75A2.25 2.25 0 0 1 15.75 21H5.25A2.25 2.25 0 0 1 3 18.75V8.25A2.25 2.25 0 0 1 5.25 6H10" />
                                            </svg>
                                        </a>
                                    </div>

                                    <a href="<?php echo e(route('treetask.tarefas.show', $tarefa->id_tarefa)); ?>" class="block mt-2">
                                        <div class="flex justify-between items-center text-xs">
                                            <?php if($tarefa->responsavel): ?>
                                                <div class="bg-gray-100 text-gray-600 px-2 py-0.5 rounded-full" title="Responsável">
                                                    <?php echo e(Str::limit($tarefa->responsavel->name, 10)); ?>

                                                </div>
                                            <?php else: ?>
                                                <span></span>
                                            <?php endif; ?>

                                            <?php if($tarefa->data_vencimento): ?>
                                                <span class="<?php echo e($isConcluido ? 'text-green-600' : (\Carbon\Carbon::parse($tarefa->data_vencimento)->isPast() ? 'text-red-600 font-bold' : 'text-gray-500')); ?>">
                        <?php echo e($isConcluido ? 'CONCLUÍDO' : \Carbon\Carbon::parse($tarefa->data_vencimento)->format('d/m')); ?>

                    </span>
                                            <?php else: ?>
                                                <span class="<?php echo e($isConcluido ? 'text-green-600' : 'text-gray-400'); ?>"><?php echo e($isConcluido ? 'CONCLUÍDO' : ''); ?></span>
                                            <?php endif; ?>
                                        </div>
                                    </a>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>

                        <div class="p-2 border-t border-gray-200">
                            <a href="<?php echo e(route('treetask.tarefas.create', $fase->id_fase)); ?>"
                               class="block w-full text-center py-2 px-4 border border-dashed border-gray-400 rounded text-gray-600 hover:bg-gray-200 hover:border-gray-500 text-sm transition">
                                + Adicionar Tarefa
                            </a>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                <div class="min-w-[300px]">
                    <form action="<?php echo e(route('treetask.fases.store')); ?>" method="POST"
                          class="bg-white bg-opacity-50 p-4 rounded-lg border-2 border-dashed border-gray-300">
                        <?php echo csrf_field(); ?>
                        <input type="hidden" name="id_projeto" value="<?php echo e($projeto->id_projeto); ?>">
                        <label class="block text-sm font-bold text-gray-700 mb-2">Nova Fase</label>
                        <input type="text" name="nome" placeholder="Ex: Validação, Concluído..."
                               class="w-full rounded border-gray-300 shadow-sm text-sm mb-2" required>
                        <button type="submit"
                                class="w-full bg-gray-600 hover:bg-gray-800 text-white py-1 px-2 rounded text-sm">
                            Adicionar Coluna
                        </button>
                    </form>
                </div>

            </div>
        </div>
    </div>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/Sortable/1.15.0/Sortable.min.js"></script>
    <script>
        document.addEventListener('DOMContentLoaded', function () {
            const csrfToken = document.querySelector('meta[name="csrf-token"]').getAttribute('content');

            // Funcao genérica para enviar a ordem
            function saveOrder(url, ids) {
                fetch(url, {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                        'X-CSRF-TOKEN': csrfToken
                    },
                    body: JSON.stringify({ids: ids})
                }).then(response => console.log('Ordem salva'));
            }

            // 1. Ordenação de FASES (Horizontal)
            const fasesContainer = document.getElementById('kanban-container');
            new Sortable(fasesContainer, {
                animation: 150,
                handle: '.fase-handle', // Só arrasta se clicar no título/handle
                ghostClass: 'bg-blue-100',
                onEnd: function () {
                    let ids = Array.from(fasesContainer.querySelectorAll('[data-fase-id]'))
                        .map(el => el.getAttribute('data-fase-id'));
                    saveOrder('<?php echo e(route("treetask.reorder.fases")); ?>', ids);
                }
            });

            // 2. Ordenação de TAREFAS (Vertical dentro das fases)
            document.querySelectorAll('.tarefas-container').forEach(container => {
                new Sortable(container, {
                    group: 'tarefas', // Permite mover entre fases (visual apenas, persistencia requer logica extra*)
                    animation: 150,
                    ghostClass: 'bg-gray-200',
                    onEnd: function (evt) {
                        // Se mudou apenas a ordem na mesma coluna
                        let ids = Array.from(evt.to.querySelectorAll('[data-tarefa-id]'))
                            .map(el => el.getAttribute('data-tarefa-id'));

                        saveOrder('<?php echo e(route("treetask.reorder.tarefas")); ?>', ids);

                        // *Nota: Se quiser permitir mover de uma fase para outra via DragDrop,
                        // a lógica seria mais complexa (atualizar id_fase).
                        // Por enquanto, focamos na ORDENAÇÃO dentro da lista.
                        // A movimentação de fase continua via Edição/Select para robustez.
                    }
                });
            });
        });
    </script>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH C:\laragon\www\portal-apps\app\Modules\TreeTask/resources/views/show.blade.php ENDPATH**/ ?>