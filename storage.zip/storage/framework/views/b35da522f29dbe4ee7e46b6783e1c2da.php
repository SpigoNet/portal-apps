<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title>Portal Spigo.Net</title>

    <!-- Fonts -->
    <link rel="preconnect" href="https://fonts.bunny.net">
    <link href="https://fonts.bunny.net/css?family=figtree:400,600&display=swap" rel="stylesheet" />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css" />


    <!-- Styles -->
    <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css', 'resources/js/app.js']); ?>
</head>
<body class="antialiased font-sans bg-spigo-dark text-white/80">
<div class="relative min-h-screen flex flex-col">
    <!-- Navigation -->
    <header class="w-full sticky top-0 bg-spigo-dark bg-opacity-90 backdrop-blur-sm z-10">
        <div class="max-w-7xl mx-auto px-6 lg:px-8">
            <div class="flex justify-between items-center py-6">
                <div>
                    <!-- IMPORTANTE: Substitua pelo caminho do seu logo pequeno -->
                    <img src="//spigo.net/manual/Spigo.Net_Marcadagua 2_Colorido.png" alt="Spigo.Net Logo Pequeno" class="h-10 w-auto"
                         onerror="this.onerror=null; this.src='https://placehold.co/150x50/322C3A/FFFFFF?text=Spigo.Net';">
                </div>
                <nav>
                    <?php if(Route::has('login')): ?>
                        <div class="flex items-center gap-6">
                            <?php if(auth()->guard()->check()): ?>
                                <a
                                    href="<?php echo e(url('/dashboard')); ?>"
                                    class="rounded-md px-3 py-2 text-spigo-lime ring-1 ring-transparent transition hover:text-white/70 focus:outline-none focus-visible:ring-[#FF2D20]"
                                >
                                    Dashboard
                                </a>
                            <?php else: ?>
                                <a
                                    href="<?php echo e(route('login')); ?>"
                                    class="rounded-md px-3 py-2 text-spigo-light-blue ring-1 ring-transparent transition hover:text-white/70 focus:outline-none focus-visible:ring-[#FF2D20]"
                                >
                                    Log in
                                </a>

                                <?php if(Route::has('register')): ?>
                                    <a
                                        href="<?php echo e(route('register')); ?>"
                                        class="rounded-md px-3 py-2 text-spigo-light-blue ring-1 ring-transparent transition hover:text-white/70 focus:outline-none focus-visible:ring-[#FF2D20]"
                                    >
                                        Register
                                    </a>
                                <?php endif; ?>
                            <?php endif; ?>
                        </div>
                    <?php endif; ?>
                </nav>
            </div>
        </div>
    </header>

    <!-- Main Content -->
    <main class="flex-grow">
        <div class="max-w-7xl mx-auto py-12 px-6 lg:px-8">
            <div class="text-center mb-12">
                <h1 class="text-4xl lg:text-5xl font-bold text-spigo-lime tracking-tight">
                    Aplicações de Acesso Público
                </h1>
                <p class="mt-4 text-lg text-spigo-violet max-w-2xl mx-auto">
                    Explore as ferramentas disponíveis para todos os visitantes. Para mais aplicações, faça login.
                </p>
            </div>

            <div class="space-y-12">
                <?php $__empty_1 = true; $__currentLoopData = $packages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $package): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <div>
                        <!-- Cabeçalho do Pacote -->
                        <div class="mb-4">
                            <h3 class="text-2xl font-bold tracking-tight text-white"><?php echo e($package->name); ?></h3>
                            <?php if($package->description): ?>
                                <p class="font-normal text-spigo-violet mt-1"><?php echo e($package->description); ?></p>
                            <?php endif; ?>
                        </div>
                        <!-- Corpo do Pacote com os ícones dos Apps -->
                        <div class="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-6">
                            <?php $__currentLoopData = $package->portalApps; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $app): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <a href="<?php echo e(url($app->start_link)); ?>" class="group block p-6 text-center bg-white/5 rounded-lg shadow-lg hover:bg-white/10 transition-all duration-300 transform hover:-translate-y-1">
                                    <i class="<?php echo e($app->icon); ?> fa-3x mb-4 text-spigo-lime transition-transform group-hover:scale-110"></i>
                                    <h5 class="font-bold tracking-tight text-white text-md">
                                        <?php echo e($app->title); ?>

                                    </h5>
                                    <p class="text-xs text-spigo-violet mt-1"><?php echo e($app->description); ?></p>
                                </a>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <div class="bg-white/5 overflow-hidden shadow-sm sm:rounded-lg">
                        <div class="p-10 text-center text-spigo-violet">
                            <p>Nenhum aplicativo público disponível no momento.</p>
                        </div>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </main>

    <!-- Footer -->
    <footer class="py-8 text-center text-sm text-white/50">
        Spigo.Net &copy; <?php echo e(date('Y')); ?>

    </footer>
</div>
</body>
</html>

<?php /**PATH C:\laragon\www\portal-apps\resources\views/welcome.blade.php ENDPATH**/ ?>