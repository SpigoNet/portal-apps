<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <div class="flex flex-col md:flex-row md:justify-between md:items-center space-y-2 md:space-y-0">
            <div class="flex items-center">
                <h2 class="font-semibold text-xl text-gray-800 leading-tight mr-4">
                    <?php echo e($projeto->nome); ?>

                </h2>
                <span class="px-2 py-1 text-xs rounded bg-gray-200 text-gray-600"><?php echo e($projeto->status); ?></span>
            </div>

            <div class="flex items-center space-x-2 overflow-x-auto">
                <a href="<?php echo e(route('treetask.index')); ?>" class="text-gray-600 hover:text-gray-900 bg-white border border-gray-300 px-3 py-1 rounded text-sm shadow-sm whitespace-nowrap">
                    📂 Projetos
                </a>

                <?php if(Route::currentRouteName() == 'treetask.show'): ?>
                    <a href="<?php echo e(route('treetask.tree.view', $projeto->id_projeto)); ?>" class="text-purple-700 hover:text-purple-900 bg-purple-50 border border-purple-200 px-3 py-1 rounded text-sm font-bold shadow-sm whitespace-nowrap">
                        Ver Árvore 🌳
                    </a>
                <?php else: ?>
                    <a href="<?php echo e(route('treetask.show', $projeto->id_projeto)); ?>" class="text-blue-700 hover:text-blue-900 bg-blue-50 border border-blue-200 px-3 py-1 rounded text-sm font-bold shadow-sm whitespace-nowrap">
                        Ver Kanban 📋
                    </a>
                <?php endif; ?>

                <span class="text-gray-300">|</span>

                <a href="<?php echo e(route('treetask.focus.index')); ?>" class="text-white bg-indigo-600 hover:bg-indigo-700 px-3 py-1 rounded text-sm font-bold shadow-sm whitespace-nowrap">
                    Modo Zen 🧘
                </a>
            </div>
        </div>
     <?php $__env->endSlot(); ?>

    <style>
        .tree-lateral {
            padding: 50px 20px;
            display: flex; /* Começa com layout horizontal */
            align-items: flex-start;
            min-height: 80vh; /* Altura mínima para rolagem lateral */
            overflow-x: auto;
            background-color: #f8fafc;
        }

        /* Conectores */
        .tree-lateral ul, .tree-lateral li {
            list-style: none;
            padding: 0;
            margin: 0;
            position: relative;
        }

        .tree-lateral ul {
            display: flex;
            flex-direction: column; /* Filhos na vertical */
            padding-left: 50px; /* Espaço para a linha vertical */
        }

        .tree-lateral li {
            margin: 15px 0;
            display: flex;
            align-items: center;
        }

        /* Linhas Verticais e Horizontais */
        .tree-lateral li::before {
            content: '';
            position: absolute;
            top: 50%;
            left: -50px; /* Horizontal para o pai */
            width: 45px;
            height: 0;
            border-top: 2px solid #ccc;
        }
        .tree-lateral li::after {
            content: '';
            position: absolute;
            top: 0;
            left: -50px;
            width: 0;
            height: 100%;
            border-left: 2px solid #ccc; /* Linha vertical que conecta os irmãos */
        }

        /* Ajustes de Pontas e Raiz */
        .tree-lateral li:first-child::after {
            top: 50%; /* Começa no meio do primeiro item */
        }
        .tree-lateral li:last-child::after {
            height: 50%; /* Termina no meio do último item */
            border-radius: 0 0 0 5px;
        }
        .tree-lateral li:only-child::after {
            display: none; /* Se for filho único, não precisa de linha vertical */
        }
        .tree-lateral > li::before {
            border: none !important; /* Raiz não tem linha esquerda */
        }

        /* Ajuste para o UL (vertical line) */
        .tree-lateral ul:not(:first-child)::before {
            content: '';
            position: absolute;
            top: 50%;
            left: -50px;
            width: 50px;
            height: 0;
            border-top: 2px solid #ccc;
        }

        /* Estilo dos Cards (Nós) - Reutilizando o formato arredondado */
        .node {
            padding: 10px 15px;
            border-radius: 8px;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
            min-width: 150px;
            transition: all 0.2s;
            position: relative;
            z-index: 10;
        }
        .node:hover {
            transform: scale(1.05);
            box-shadow: 0 6px 10px rgba(0,0,0,0.15);
        }
        .node-root { background-color: #1e293b; color: white; border: 3px solid #0f172a; font-weight: bold; min-width: 200px; }
        .node-phase { background-color: #f1f5f9; border-left: 5px solid #64748b; font-weight: 600; }
        .node-task { background-color: white; border-left: 4px solid #94a3af; font-size: 0.9rem; }

        /* Status Cores */
        .status-concluido { border-color: #10b981 !important; background-color: #ecfdf5 !important; opacity: 0.8; }
        .status-andamento { border-color: #3b82f6 !important; background-color: #eff6ff !important; }
        .status-aguardando { border-color: #f59e0b !important; background-color: #fffbeb !important; }
    </style>

    <div class="tree-lateral">
        <ul>
            <li>
                <div class="node node-root">
                    <?php echo e($projeto->nome); ?>

                    <div class="text-xs font-normal mt-1 opacity-80">Objetivo Principal</div>
                </div>

                <?php if($projeto->fases->count() > 0): ?>
                    <ul>
                        <?php $__currentLoopData = $projeto->fases; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $fase): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li>
                                <div class="node node-phase">
                                    <?php echo e($fase->nome); ?>

                                    <div class="text-xs text-gray-500 mt-1 font-normal">Etapa</div>
                                </div>

                                <?php if($fase->tarefas->count() > 0): ?>
                                    <ul>
                                        <?php $__currentLoopData = $fase->tarefas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tarefa): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <li>
                                                <a href="<?php echo e(route('treetask.tarefas.edit', ['id' => $tarefa->id_tarefa])); ?>"
                                                   class="node node-task
                                                   <?php echo e($tarefa->status == 'Concluído' ? 'status-concluido' :
                                                     ($tarefa->status == 'Em Andamento' ? 'status-andamento' :
                                                      ($tarefa->status == 'Aguardando resposta' ? 'status-aguardando' : 'status-afazer'))); ?>">

                                                    <div class="font-bold text-gray-800"><?php echo e(Str::limit($tarefa->titulo, 20)); ?></div>

                                                    <div class="text-xs text-gray-500 mt-1">
                                                        Responsável: <?php echo e($tarefa->responsavel->name ? Str::words($tarefa->responsavel->name, 1, '') : 'N/A'); ?>

                                                    </div>
                                                </a>
                                            </li>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </ul>
                                <?php endif; ?>
                            </li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                <?php endif; ?>
            </li>
        </ul>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH C:\laragon\www\portal-apps\app\Modules\TreeTask/resources/views/tree.blade.php ENDPATH**/ ?>