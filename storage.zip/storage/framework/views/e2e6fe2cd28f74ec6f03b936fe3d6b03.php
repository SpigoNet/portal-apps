<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <div class="flex justify-between items-center">
            <h2 class="font-semibold text-xl text-gray-800 leading-tight">
                <?php echo e(__('Editar Tarefa')); ?>

            </h2>

            <div class="flex space-x-2">
                <a href="<?php echo e(route('treetask.index')); ?>" class="text-sm text-gray-600 hover:text-gray-900 underline px-2">
                    Projetos
                </a>

                <span class="text-gray-300">|</span>

                <a href="<?php echo e(route('treetask.focus.index')); ?>" class="text-sm text-indigo-600 hover:text-indigo-900 font-bold px-2">
                    Modo Zen 🧘
                </a>

                <?php if(request('origin') === 'focus'): ?>
                    <a href="<?php echo e(route('treetask.focus.index')); ?>" class="ml-4 bg-gray-200 hover:bg-gray-300 text-gray-700 py-1 px-3 rounded text-sm font-bold">
                        ⬅ Voltar
                    </a>
                <?php else: ?>
                    <a href="<?php echo e(route('treetask.show', $tarefa->fase->id_projeto)); ?>" class="ml-4 bg-gray-200 hover:bg-gray-300 text-gray-700 py-1 px-3 rounded text-sm font-bold">
                        ⬅ Voltar
                    </a>
                <?php endif; ?>
            </div>
        </div>
     <?php $__env->endSlot(); ?>

    <div class="py-12">
        <div class="max-w-3xl mx-auto sm:px-6 lg:px-8">
            <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg">
                <div class="p-6 text-gray-900">
                    <form action="<?php echo e(route('treetask.tarefas.update', $tarefa->id_tarefa)); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('PUT'); ?>
                        <input type="hidden" name="origin" value="<?php echo e(request('origin')); ?>">

                        <div class="grid grid-cols-1 md:grid-cols-2 gap-4 mb-6 bg-gray-50 p-4 rounded border border-gray-200">

                            <div>
                                <label class="block text-gray-700 text-sm font-bold mb-2">Fase (Coluna):</label>
                                <select name="id_fase" class="w-full border-gray-300 rounded-md shadow-sm focus:border-blue-500 focus:ring-blue-500">
                                    <?php $__currentLoopData = $fases; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $fase): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($fase->id_fase); ?>" <?php echo e($tarefa->id_fase == $fase->id_fase ? 'selected' : ''); ?>>
                                            <?php echo e($fase->nome); ?>

                                        </option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>

                            <div>
                                <label class="block text-gray-700 text-sm font-bold mb-2">Status da Tarefa:</label>
                                <select name="status" class="w-full border-gray-300 rounded-md shadow-sm focus:border-blue-500 focus:ring-blue-500 font-bold text-gray-700">
                                    <option value="A Fazer" <?php echo e($tarefa->status == 'A Fazer' ? 'selected' : ''); ?>>⚪ A Fazer</option>
                                    <option value="Planejamento" <?php echo e($tarefa->status == 'Planejamento' ? 'selected' : ''); ?>>🟣 Planejamento</option>
                                    <option value="Em Andamento" <?php echo e($tarefa->status == 'Em Andamento' ? 'selected' : ''); ?>>🔵 Em Andamento</option>
                                    <option value="Aguardando resposta" <?php echo e($tarefa->status == 'Aguardando resposta' ? 'selected' : ''); ?>>🟡 Aguardando resposta</option>
                                    <option value="Concluído" <?php echo e($tarefa->status == 'Concluído' ? 'selected' : ''); ?>>🟢 Concluído</option>
                                </select>
                            </div>
                        </div>

                        <div class="mb-4">
                            <label class="block text-gray-700 text-sm font-bold mb-2">Título *</label>
                            <input type="text" name="titulo" value="<?php echo e(old('titulo', $tarefa->titulo)); ?>" class="w-full border-gray-300 rounded-md shadow-sm" required>
                        </div>

                        <div class="mb-4">
                            <label class="block text-gray-700 text-sm font-bold mb-2">Descrição</label>
                            <textarea name="descricao" rows="5" class="w-full border-gray-300 rounded-md shadow-sm"><?php echo e(old('descricao', $tarefa->descricao)); ?></textarea>
                        </div>

                        <div class="grid grid-cols-1 md:grid-cols-2 gap-4 mb-6">
                            <div>
                                <label class="block text-gray-700 text-sm font-bold mb-2">Responsável *</label>
                                <select name="id_user_responsavel" class="w-full border-gray-300 rounded-md shadow-sm" required>
                                    <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($user->id); ?>" <?php echo e($tarefa->id_user_responsavel == $user->id ? 'selected' : ''); ?>>
                                            <?php echo e($user->name); ?>

                                        </option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>

                            <div>
                                <label class="block text-gray-700 text-sm font-bold mb-2">Prioridade</label>
                                <select name="prioridade" class="w-full border-gray-300 rounded-md shadow-sm">
                                    <?php $__currentLoopData = ['Baixa', 'Média', 'Alta', 'Urgente']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $prio): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($prio); ?>" <?php echo e($tarefa->prioridade == $prio ? 'selected' : ''); ?>><?php echo e($prio); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>

                            <div>
                                <label class="block text-gray-700 text-sm font-bold mb-2">Vencimento</label>
                                <input type="date" name="data_vencimento"
                                       value="<?php echo e($tarefa->data_vencimento ? \Carbon\Carbon::parse($tarefa->data_vencimento)->format('Y-m-d') : ''); ?>"
                                       class="w-full border-gray-300 rounded-md shadow-sm">
                            </div>

                            <div>
                                <label class="block text-gray-700 text-sm font-bold mb-2">Estimativa (h)</label>
                                <input type="number" step="0.5" name="estimativa_tempo" value="<?php echo e(old('estimativa_tempo', $tarefa->estimativa_tempo)); ?>" class="w-full border-gray-300 rounded-md shadow-sm">
                            </div>
                        </div>

                        <div class="flex justify-end space-x-3 pt-4 border-t border-gray-100">
                            <a href="<?php echo e(url()->previous()); ?>" class="px-4 py-2 bg-white border border-gray-300 text-gray-700 rounded shadow-sm hover:bg-gray-50">Cancelar</a>
                            <button type="submit" class="px-4 py-2 bg-blue-600 text-white font-bold rounded shadow hover:bg-blue-700">Salvar Alterações</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH C:\laragon\www\portal-apps\app\Modules\TreeTask/resources/views/tarefas/edit.blade.php ENDPATH**/ ?>