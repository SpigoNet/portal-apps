<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <div class="flex items-center justify-between">
            <h2 class="font-semibold text-xl text-gray-800 dark:text-gray-200 leading-tight">
                <?php echo e(__('Editar Formulário: ') . $form->name); ?>

            </h2>
            <div class="flex space-x-2">
                
                <a href="<?php echo e(route('dspace-forms.forms.index')); ?>">
                    <?php if (isset($component)) { $__componentOriginal3b0e04e43cf890250cc4d85cff4d94af = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal3b0e04e43cf890250cc4d85cff4d94af = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.secondary-button','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('secondary-button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
                        <i class="fa-solid fa-arrow-left mr-2"></i> <?php echo e(__('Voltar à Lista')); ?>

                     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal3b0e04e43cf890250cc4d85cff4d94af)): ?>
<?php $attributes = $__attributesOriginal3b0e04e43cf890250cc4d85cff4d94af; ?>
<?php unset($__attributesOriginal3b0e04e43cf890250cc4d85cff4d94af); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal3b0e04e43cf890250cc4d85cff4d94af)): ?>
<?php $component = $__componentOriginal3b0e04e43cf890250cc4d85cff4d94af; ?>
<?php unset($__componentOriginal3b0e04e43cf890250cc4d85cff4d94af); ?>
<?php endif; ?>
                </a>

                
                <a href="<?php echo e(route('dspace-forms.index')); ?>">
                    <?php if (isset($component)) { $__componentOriginal3b0e04e43cf890250cc4d85cff4d94af = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal3b0e04e43cf890250cc4d85cff4d94af = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.secondary-button','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('secondary-button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
                        <i class="fa-solid fa-house mr-2"></i> <?php echo e(__('Início')); ?>

                     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal3b0e04e43cf890250cc4d85cff4d94af)): ?>
<?php $attributes = $__attributesOriginal3b0e04e43cf890250cc4d85cff4d94af; ?>
<?php unset($__attributesOriginal3b0e04e43cf890250cc4d85cff4d94af); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal3b0e04e43cf890250cc4d85cff4d94af)): ?>
<?php $component = $__componentOriginal3b0e04e43cf890250cc4d85cff4d94af; ?>
<?php unset($__componentOriginal3b0e04e43cf890250cc4d85cff4d94af); ?>
<?php endif; ?>
                </a>
            </div>
        </div>
     <?php $__env->endSlot(); ?>

    <div class="py-12">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8 space-y-6">

            <?php if (isset($component)) { $__componentOriginal7c1bf3a9346f208f66ee83b06b607fb5 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal7c1bf3a9346f208f66ee83b06b607fb5 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.auth-session-status','data' => ['class' => 'mb-4','status' => session('success')]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('auth-session-status'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'mb-4','status' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(session('success'))]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal7c1bf3a9346f208f66ee83b06b607fb5)): ?>
<?php $attributes = $__attributesOriginal7c1bf3a9346f208f66ee83b06b607fb5; ?>
<?php unset($__attributesOriginal7c1bf3a9346f208f66ee83b06b607fb5); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal7c1bf3a9346f208f66ee83b06b607fb5)): ?>
<?php $component = $__componentOriginal7c1bf3a9346f208f66ee83b06b607fb5; ?>
<?php unset($__componentOriginal7c1bf3a9346f208f66ee83b06b607fb5); ?>
<?php endif; ?>
            <?php if(session('error')): ?>
                <div class="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded relative mb-4" role="alert">
                    <span class="block sm:inline"><?php echo e(session('error')); ?></span>
                </div>
            <?php endif; ?>

            <div class="bg-white dark:bg-gray-800 shadow sm:rounded-lg">
                <div class="p-6 text-gray-900 dark:text-gray-100">
                    <h3 class="text-lg font-medium text-gray-900 dark:text-gray-100 mb-4">
                        <?php echo e(__('Informações Básicas')); ?>

                    </h3>
                    <form method="POST" action="<?php echo e(route('dspace-forms.forms.update', $form)); ?>">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('PUT'); ?>

                        <?php echo $__env->make('DspaceForms::forms._form', ['form' => $form], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

                        <div class="flex items-center justify-end mt-6">
                            <?php if (isset($component)) { $__componentOriginald411d1792bd6cc877d687758b753742c = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginald411d1792bd6cc877d687758b753742c = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.primary-button','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('primary-button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
                                <?php echo e(__('Salvar Alterações')); ?>

                             <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginald411d1792bd6cc877d687758b753742c)): ?>
<?php $attributes = $__attributesOriginald411d1792bd6cc877d687758b753742c; ?>
<?php unset($__attributesOriginald411d1792bd6cc877d687758b753742c); ?>
<?php endif; ?>
<?php if (isset($__componentOriginald411d1792bd6cc877d687758b753742c)): ?>
<?php $component = $__componentOriginald411d1792bd6cc877d687758b753742c; ?>
<?php unset($__componentOriginald411d1792bd6cc877d687758b753742c); ?>
<?php endif; ?>
                        </div>
                    </form>
                </div>
            </div>

            <div class="bg-white dark:bg-gray-800 shadow sm:rounded-lg">
                <div class="p-6 text-gray-900 dark:text-gray-100">
                    <h3 class="text-lg font-medium text-gray-900 dark:text-gray-100 mb-4">
                        <?php echo e(__('Estrutura do Formulário: Linhas e Campos')); ?>

                    </h3>

                    <div class="mb-6 flex justify-end">
                        <form method="POST" action="<?php echo e(route('dspace-forms.forms.rows.store', $form)); ?>">
                            <?php echo csrf_field(); ?>
                            <?php if (isset($component)) { $__componentOriginal3b0e04e43cf890250cc4d85cff4d94af = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal3b0e04e43cf890250cc4d85cff4d94af = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.secondary-button','data' => ['type' => 'submit','class' => 'bg-indigo-600 hover:bg-indigo-700 text-white']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('secondary-button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['type' => 'submit','class' => 'bg-indigo-600 hover:bg-indigo-700 text-white']); ?>
                                <i class="fa-solid fa-layer-group mr-2"></i> <?php echo e(__('Adicionar Nova Linha')); ?>

                             <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal3b0e04e43cf890250cc4d85cff4d94af)): ?>
<?php $attributes = $__attributesOriginal3b0e04e43cf890250cc4d85cff4d94af; ?>
<?php unset($__attributesOriginal3b0e04e43cf890250cc4d85cff4d94af); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal3b0e04e43cf890250cc4d85cff4d94af)): ?>
<?php $component = $__componentOriginal3b0e04e43cf890250cc4d85cff4d94af; ?>
<?php unset($__componentOriginal3b0e04e43cf890250cc4d85cff4d94af); ?>
<?php endif; ?>
                        </form>
                    </div>

                    <?php
                        // Carrega as linhas ordenadas e calcula o min/max order para desabilitar botões
                        $allRows = $form->rows()->with('fields')->orderBy('order')->get();
                        $minRowOrder = $allRows->min('order');
                        $maxRowOrder = $allRows->max('order');
                    ?>

                    <ul class="space-y-4">
                        <?php $__empty_1 = true; $__currentLoopData = $allRows; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <li class="bg-gray-100 dark:bg-gray-700 p-4 rounded-lg shadow-md border-t-4 border-indigo-500">

                                <div class="flex justify-between items-center mb-4">
                                    <h4 class="font-bold text-lg text-gray-800 dark:text-gray-200">
                                        Linha #<?php echo e($row->order); ?>

                                    </h4>
                                    <div class="flex space-x-2 items-center">

                                        <div class="flex flex-col space-y-1">
                                            
                                            <form method="POST"
                                                  action="<?php echo e(route('dspace-forms.forms.rows.move', [$form, $row])); ?>">
                                                <?php echo csrf_field(); ?>
                                                <input type="hidden" name="direction" value="up">
                                                <button type="submit" <?php if($row->order === $minRowOrder): ?> disabled
                                                        <?php endif; ?> class="text-gray-600 dark:text-gray-400 disabled:opacity-30 disabled:cursor-not-allowed hover:text-indigo-600 dark:hover:text-indigo-400 transition">
                                                    <i class="fa-solid fa-chevron-up"></i>
                                                </button>
                                            </form>
                                            
                                            <form method="POST"
                                                  action="<?php echo e(route('dspace-forms.forms.rows.move', [$form, $row])); ?>">
                                                <?php echo csrf_field(); ?>
                                                <input type="hidden" name="direction" value="down">
                                                <button type="submit" <?php if($row->order === $maxRowOrder): ?> disabled
                                                        <?php endif; ?> class="text-gray-600 dark:text-gray-400 disabled:opacity-30 disabled:cursor-not-allowed hover:text-indigo-600 dark:hover:text-indigo-400 transition">
                                                    <i class="fa-solid fa-chevron-down"></i>
                                                </button>
                                            </form>
                                        </div>

                                        <?php if (isset($component)) { $__componentOriginal3b0e04e43cf890250cc4d85cff4d94af = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal3b0e04e43cf890250cc4d85cff4d94af = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.secondary-button','data' => ['onclick' => 'openFieldModalForCreation('.e($row->id).')','class' => 'bg-green-600 hover:bg-green-700 text-white']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('secondary-button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['onclick' => 'openFieldModalForCreation('.e($row->id).')','class' => 'bg-green-600 hover:bg-green-700 text-white']); ?>
                                            <i class="fa-solid fa-plus-circle mr-2"></i> <?php echo e(__('Adicionar Campo')); ?>

                                         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal3b0e04e43cf890250cc4d85cff4d94af)): ?>
<?php $attributes = $__attributesOriginal3b0e04e43cf890250cc4d85cff4d94af; ?>
<?php unset($__attributesOriginal3b0e04e43cf890250cc4d85cff4d94af); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal3b0e04e43cf890250cc4d85cff4d94af)): ?>
<?php $component = $__componentOriginal3b0e04e43cf890250cc4d85cff4d94af; ?>
<?php unset($__componentOriginal3b0e04e43cf890250cc4d85cff4d94af); ?>
<?php endif; ?>

                                        <form method="POST"
                                              action="<?php echo e(route('dspace-forms.forms.rows.destroy', [$form, $row])); ?>">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('DELETE'); ?>
                                            <?php if (isset($component)) { $__componentOriginal656e8c5ea4d9a4fa173298297bfe3f11 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal656e8c5ea4d9a4fa173298297bfe3f11 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.danger-button','data' => ['type' => 'submit','onclick' => 'return confirm(\'Tem certeza que deseja excluir esta linha e todos os campos dentro dela?\')','class' => 'text-white bg-red-600 hover:bg-red-700']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('danger-button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['type' => 'submit','onclick' => 'return confirm(\'Tem certeza que deseja excluir esta linha e todos os campos dentro dela?\')','class' => 'text-white bg-red-600 hover:bg-red-700']); ?>
                                                <i class="fa-solid fa-trash"></i>
                                             <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal656e8c5ea4d9a4fa173298297bfe3f11)): ?>
<?php $attributes = $__attributesOriginal656e8c5ea4d9a4fa173298297bfe3f11; ?>
<?php unset($__attributesOriginal656e8c5ea4d9a4fa173298297bfe3f11); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal656e8c5ea4d9a4fa173298297bfe3f11)): ?>
<?php $component = $__componentOriginal656e8c5ea4d9a4fa173298297bfe3f11; ?>
<?php unset($__componentOriginal656e8c5ea4d9a4fa173298297bfe3f11); ?>
<?php endif; ?>
                                        </form>
                                    </div>
                                </div>

                                <div class="pl-4 border-l border-gray-300 dark:border-gray-600">
                                    <h5 class="text-sm font-semibold mb-2 text-gray-600 dark:text-gray-400">Campos nesta
                                        Linha:</h5>
                                    <ul class="space-y-2 min-h-[50px]">
                                        <?php
                                            $fields = $row->fields()->orderBy('order')->get();
                                            $minFieldOrder = $fields->min('order');
                                            $maxFieldOrder = $fields->max('order');
                                        ?>
                                        <?php $__empty_2 = true; $__currentLoopData = $fields; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $field): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_2 = false; ?>
                                            <li class="bg-white dark:bg-gray-800 p-3 rounded-md shadow-sm border border-gray-200 dark:border-gray-700 flex justify-between items-center">
                                                <div>
                                                    <span class="font-medium text-indigo-600 dark:text-indigo-400">
                                                        <?php echo e($field->dc_schema); ?>.<?php echo e($field->dc_element); ?><?php echo e($field->dc_qualifier ? '.'.$field->dc_qualifier : ''); ?>

                                                    </span>
                                                    <span class="text-sm text-gray-500 dark:text-gray-400"> (<?php echo e($field->label); ?>)</span>
                                                </div>
                                                <div class="flex space-x-2 items-center">

                                                    <div class="flex flex-col space-y-1">
                                                        
                                                        <form method="POST"
                                                              action="<?php echo e(route('dspace-forms.forms.rows.fields.move', [$form, $row, $field])); ?>">
                                                            <?php echo csrf_field(); ?>
                                                            <input type="hidden" name="direction" value="up">
                                                            <button type="submit"
                                                                    <?php if($field->order === $minFieldOrder): ?> disabled
                                                                    <?php endif; ?> class="text-gray-600 dark:text-gray-400 disabled:opacity-30 disabled:cursor-not-allowed hover:text-indigo-600 dark:hover:text-indigo-400 transition">
                                                                <i class="fa-solid fa-chevron-up text-xs"></i>
                                                            </button>
                                                        </form>
                                                        
                                                        <form method="POST"
                                                              action="<?php echo e(route('dspace-forms.forms.rows.fields.move', [$form, $row, $field])); ?>">
                                                            <?php echo csrf_field(); ?>
                                                            <input type="hidden" name="direction" value="down">
                                                            <button type="submit"
                                                                    <?php if($field->order === $maxFieldOrder): ?> disabled
                                                                    <?php endif; ?> class="text-gray-600 dark:text-gray-400 disabled:opacity-30 disabled:cursor-not-allowed hover:text-indigo-600 dark:hover:text-indigo-400 transition">
                                                                <i class="fa-solid fa-chevron-down text-xs"></i>
                                                            </button>
                                                        </form>
                                                    </div>

                                                    
                                                    
                                                    <?php if (isset($component)) { $__componentOriginal3b0e04e43cf890250cc4d85cff4d94af = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal3b0e04e43cf890250cc4d85cff4d94af = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.secondary-button','data' => ['onclick' => 'openFieldModalForEdit('.e($row->id).', '.e($field->id).', \''.e($field->toJson()).'\')','class' => 'text-xs py-1']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('secondary-button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['onclick' => 'openFieldModalForEdit('.e($row->id).', '.e($field->id).', \''.e($field->toJson()).'\')','class' => 'text-xs py-1']); ?>
                                                        <i class="fa-solid fa-pencil"></i> <?php echo e(__('Editar')); ?>

                                                     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal3b0e04e43cf890250cc4d85cff4d94af)): ?>
<?php $attributes = $__attributesOriginal3b0e04e43cf890250cc4d85cff4d94af; ?>
<?php unset($__attributesOriginal3b0e04e43cf890250cc4d85cff4d94af); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal3b0e04e43cf890250cc4d85cff4d94af)): ?>
<?php $component = $__componentOriginal3b0e04e43cf890250cc4d85cff4d94af; ?>
<?php unset($__componentOriginal3b0e04e43cf890250cc4d85cff4d94af); ?>
<?php endif; ?>

                                                    <form method="POST"
                                                          action="<?php echo e(route('dspace-forms.forms.rows.fields.destroy', [$form, $row, $field])); ?>">
                                                        <?php echo csrf_field(); ?>
                                                        <?php echo method_field('DELETE'); ?>
                                                        <?php if (isset($component)) { $__componentOriginal656e8c5ea4d9a4fa173298297bfe3f11 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal656e8c5ea4d9a4fa173298297bfe3f11 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.danger-button','data' => ['type' => 'submit','onclick' => 'return confirm(\'Tem certeza que deseja excluir este campo?\')','class' => 'text-xs py-1']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('danger-button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['type' => 'submit','onclick' => 'return confirm(\'Tem certeza que deseja excluir este campo?\')','class' => 'text-xs py-1']); ?>
                                                            <i class="fa-solid fa-trash"></i>
                                                         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal656e8c5ea4d9a4fa173298297bfe3f11)): ?>
<?php $attributes = $__attributesOriginal656e8c5ea4d9a4fa173298297bfe3f11; ?>
<?php unset($__attributesOriginal656e8c5ea4d9a4fa173298297bfe3f11); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal656e8c5ea4d9a4fa173298297bfe3f11)): ?>
<?php $component = $__componentOriginal656e8c5ea4d9a4fa173298297bfe3f11; ?>
<?php unset($__componentOriginal656e8c5ea4d9a4fa173298297bfe3f11); ?>
<?php endif; ?>
                                                    </form>
                                                </div>
                                            </li>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_2): ?>
                                            <p class="text-sm text-gray-500 dark:text-gray-400 p-2 text-center">Nenhum
                                                campo nesta linha.</p>
                                        <?php endif; ?>
                                    </ul>
                                </div>
                            </li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <p class="text-center text-gray-500 dark:text-gray-400">Nenhuma linha configurada. Use o
                                botão "Adicionar Nova Linha" para começar.</p>
                        <?php endif; ?>
                    </ul>

                    <?php if (isset($component)) { $__componentOriginal9f64f32e90b9102968f2bc548315018c = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9f64f32e90b9102968f2bc548315018c = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.modal','data' => ['name' => 'edit-field-modal','show' => false,'focusable' => true]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('modal'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'edit-field-modal','show' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(false),'focusable' => true]); ?>
                        <div class="p-6">
                            <h2 id="field-modal-title"
                                class="text-lg font-medium text-gray-900 dark:text-gray-100"></h2>
                            <p class="mt-1 text-sm text-gray-600 dark:text-gray-400">
                                <?php echo e(__('Configure os metadados e o tipo de campo DSpace.')); ?>

                            </p>

                            <?php echo $__env->make('DspaceForms::forms.fields._modal_form', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

                        </div>
                     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9f64f32e90b9102968f2bc548315018c)): ?>
<?php $attributes = $__attributesOriginal9f64f32e90b9102968f2bc548315018c; ?>
<?php unset($__attributesOriginal9f64f32e90b9102968f2bc548315018c); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9f64f32e90b9102968f2bc548315018c)): ?>
<?php $component = $__componentOriginal9f64f32e90b9102968f2bc548315018c; ?>
<?php unset($__componentOriginal9f64f32e90b9102968f2bc548315018c); ?>
<?php endif; ?>

                </div>
            </div>

        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>

<script>
    // --- FUNÇÕES DE UTILIDADE E GESTÃO DE MODAL ---

    // Esta função nativa dispara o evento que o componente x-modal (Alpine.js) está ouvindo
    function openModalAlpine(modalName) {
        window.dispatchEvent(new CustomEvent('open-modal', {detail: modalName}));
    }

    // Função para mostrar/esconder o campo de seleção de lista
    window.toggleListSelection = function (inputType) {
        // Tipos de input que requerem uma lista (dropdown, list, lookup)
        const isListType = inputType === 'dropdown' || inputType === 'list' || inputType === 'lookup';

        const listGroup = document.getElementById('list-selection-group');
        const closedGroup = document.getElementById('vocabulary-closed-group');

        if (listGroup) {
            if (isListType) {
                listGroup.style.display = 'block';
                closedGroup.style.display = 'flex'; // Usamos 'flex' para o componente x-modal
            } else {
                listGroup.style.display = 'none';
                closedGroup.style.display = 'none';

                // Limpa o campo de seleção e desmarca o checkbox para evitar envio de dados incorretos
                document.getElementById('list_selection').value = '';
                document.getElementById('vocabulary_closed').checked = false;
            }
        }
    }

    // Função utilitária para preencher o formulário
    function fillFieldForm(fieldData) {
        // Garante que booleanos e nulos sejam tratados corretamente
        fieldData.repeatable = !!fieldData.repeatable;
        fieldData.vocabulary_closed = !!fieldData.vocabulary_closed;

        // NOVO: Calcula o valor da lista combinada
        let combinedListValue = '';
        if (fieldData.vocabulary) {
            combinedListValue = 'detailed:' + fieldData.vocabulary;
        } else if (fieldData.value_pairs_name) {
            combinedListValue = 'simple:' + fieldData.value_pairs_name;
        }

        // Preenchimento de campos de texto e select
        document.getElementById('dc_schema').value = fieldData.dc_schema || 'dc';
        document.getElementById('dc_element').value = fieldData.dc_element || '';
        document.getElementById('dc_qualifier').value = fieldData.dc_qualifier || '';
        document.getElementById('label').value = fieldData.label || '';

        // Define o input_type E aciona a função de visibilidade
        document.getElementById('input_type').value = fieldData.input_type || 'onebox';
        window.toggleListSelection(fieldData.input_type || 'onebox');

        // Define o valor do novo campo consolidado
        document.getElementById('list_selection').value = combinedListValue;

        document.getElementById('hint').value = fieldData.hint || '';
        document.getElementById('required').value = fieldData.required || '';
        document.getElementById('vocabulary').value = fieldData.vocabulary || ''; // Campo antigo, mas ainda deve ser preenchido para segurança

        // Preenchimento de checkboxes
        document.getElementById('repeatable').checked = fieldData.repeatable;
        document.getElementById('vocabulary_closed').checked = fieldData.vocabulary_closed;

        // Oculta/Exibe o campo hidden para garantir o envio de '0' ou '1'
        document.getElementById('repeatable-hidden').name = fieldData.repeatable ? '' : 'repeatable';
        document.getElementById('vocabulary_closed-hidden').name = fieldData.vocabulary_closed ? '' : 'vocabulary_closed';
    }

    // --- FUNÇÕES DE AÇÃO DO MODAL ---

    // As URLs base para o form
    const formId = <?php echo e($form->id); ?>;
    const baseUrl = '/dspace-forms-editor/forms/' + formId + '/rows/';

    // Abre o modal para CRIAÇÃO
    window.openFieldModalForCreation = function (rowId) {
        document.getElementById('field-modal-title').textContent = 'Criar Novo Campo';
        document.getElementById('field-modal-submit-text').textContent = 'Criar Campo';

        // Configura a URL de Ação para POST (Store)
        const actionUrl = baseUrl + rowId + '/fields';
        document.getElementById('field-modal-form').setAttribute('action', actionUrl);
        document.getElementById('_method').value = 'POST';

        // Limpa o formulário (ou preenche com valores padrão de um campo novo)
        fillFieldForm({
            id: null, dc_schema: 'dc', dc_element: '', dc_qualifier: '', repeatable: true,
            label: 'Novo Campo', input_type: 'onebox', hint: '', required: '', vocabulary: '',
            vocabulary_closed: false, value_pairs_name: ''
        });

        openModalAlpine('edit-field-modal');
    }

    // Abre o modal para EDIÇÃO
    window.openFieldModalForEdit = function (rowId, fieldId, fieldDataJson) {
        const fieldData = JSON.parse(fieldDataJson);

        document.getElementById('field-modal-title').textContent = 'Editar Campo: ' + fieldData.label;
        document.getElementById('field-modal-submit-text').textContent = 'Salvar Campo';

        // Configura a URL de Ação para PUT (Update)
        const actionUrl = baseUrl + rowId + '/fields/' + fieldId;
        document.getElementById('field-modal-form').setAttribute('action', actionUrl);
        document.getElementById('_method').value = 'PUT';

        // Preenche o formulário com os dados do campo
        fillFieldForm(fieldData);

        openModalAlpine('edit-field-modal');
    }
</script>
<?php /**PATH C:\laragon\www\portal-apps\app\Modules\DspaceForms/resources/views/forms/edit.blade.php ENDPATH**/ ?>